function thumbChange(num) {
  var thumb = "../image/thumb/bg-image" + num + ".jpg";
  document.getElementById("mainImg").src = thumb;
}
